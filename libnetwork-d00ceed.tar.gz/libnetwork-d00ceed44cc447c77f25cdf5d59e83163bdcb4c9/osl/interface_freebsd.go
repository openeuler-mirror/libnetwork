package osl

// IfaceOption is a function option type to set interface options
type IfaceOption func()
